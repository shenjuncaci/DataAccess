﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SendEmailApp
{
    //虚拟类
    public class MailHelperDTO
    {
    }
}
