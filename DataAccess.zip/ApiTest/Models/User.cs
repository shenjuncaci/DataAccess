﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApiTest
{
    public class User
    {
        public string userName { get; set; }
        public string test { get; set; }
    }
}