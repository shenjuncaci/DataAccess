﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestApp
{
    //虚拟类，方便使用工厂模式
    public class BIQS
    {
    }
}